package com.sample.framework.ui;

public enum ScrollTo {
	TOP_ONLY, BOTTOM_ONLY, TOP_BOTTOM, BOTTOM_TOP
}
